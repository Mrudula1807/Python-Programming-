a=input("enter the month : ")
b=int(input("enter the date : "))
if a in('mar','apr','may'):
    season='summer'
elif a in('jun','jul','aug'):
    season='spring'
elif a in('sep','oct','nov'):
    season='Fall'
elif a in('dec','jan','feb'):
    season='winter'
if(a=='mar') and(b>20):
    season='summer'
elif(a=='jun') and(b>21):
    season='spring'
elif(a=='sep')and (b>22):
    season='fall'
elif(a=='dec')and(b>21):
    season='winter'
print("season is:",season)
