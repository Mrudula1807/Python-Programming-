def areIsomorphic(str1, str2):
	charCount = dict()
	c = "a"
	for i in range(len(str1)):
		if str1[i] in charCount:
			c = charCount[str1[i]]
			if c != str2[i]:
				return False
		elif str2[i] not in charCount.values():
			charCount[str1[i]] = str2[i]
		else:
			return False
	return True
str1 = str(input('enter the string1:'))
str2 = str(input('enter the string2:'))
if (len(str1) == len(str2) and areIsomorphic(str1, str2)):
	print("True")
else:
	print("False")
