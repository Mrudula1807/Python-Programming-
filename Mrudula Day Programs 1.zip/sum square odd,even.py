a=int(input("enter the no of elements :"))
b=[]
even=0
odd=0
for i in range(1,a+1,1):
    c=int(input("enter the element :"))
    b.append(c)
for i in b:
    if i%2==0:
        even=even+i**2
    else:
        odd=odd+i**2
b=[odd,even]
print(b)
