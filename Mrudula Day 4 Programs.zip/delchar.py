def remove_char(s1,s2):
    print(s1.replace(s2, ''))
s1 = input("Enter a String : ")
s2 = input("Enter a Character to be deleted : ")
remove_char(s1,s2) 
